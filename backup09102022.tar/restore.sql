--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.12
-- Dumped by pg_dump version 12.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Basketball";
--
-- Name: Basketball; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Basketball" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE "Basketball" OWNER TO postgres;

\connect "Basketball"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: add_to_sponsor_player(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.add_to_sponsor_player() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE 
table_string RECORD;
query_string text := '';
begin
query_string := 'SELECT name FROM contract_sponsor_player';
for table_string in EXECUTE query_string
LOOP
if new.name=table_string THEN
RAISE EXCEPTION 'Invalid expiration date';
END IF;
END LOOP;
RETURN NEW;
END;
$$;


ALTER FUNCTION public.add_to_sponsor_player() OWNER TO postgres;

--
-- Name: coach_c(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.coach_c() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
if ((select Bol from kld where Polzovatel='admin')=true) THEN
insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'coach',new.ID,'insert',now());
insert into tmp_coach(id,name,speciality,team_id) 
values(new.id,new.name,new.speciality,new.team_id);
end if;
return new;
end;
$$;


ALTER FUNCTION public.coach_c() OWNER TO postgres;

--
-- Name: coach_d(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.coach_d() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'coach',old.ID,'delete',now());
	insert into tmp_coach(id,name,speciality,team_id) 
	values(old.id,old.name,old.speciality,old.team_id);
	end if;
	return  null;
	end;
	$$;


ALTER FUNCTION public.coach_d() OWNER TO postgres;

--
-- Name: coach_u(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.coach_u() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
if ((select Bol from kld where Polzovatel='admin')=true) THEN
insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'coach',new.ID,'update',now());
insert into tmp_coach(id,name,speciality,team_id) 
values(old.id,old.name,old.speciality,old.team_id);
end if;
return new;
end;
$$;


ALTER FUNCTION public.coach_u() OWNER TO postgres;

--
-- Name: coachupdate(bigint, character varying, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.coachupdate(_id bigint, _name character varying, _speciality character varying, _team_id integer)
    LANGUAGE sql
    AS $$
UPDATE coach set
	name=_Name,
	speciality=_speciality,
	team_id=_team_id
	where id=_id;
$$;


ALTER PROCEDURE public.coachupdate(_id bigint, _name character varying, _speciality character varying, _team_id integer) OWNER TO postgres;

--
-- Name: contract_sponsor_player_c(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.contract_sponsor_player_c() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda,name) values('admin',42,'contract_sponsor_player',new.player_id,'insert',now(),new.name);
	insert into tmp_contract_sponsor_player(id,name,player_id,contract_sum) 
	values(new.player_id,new.name,new.player_id,new.contract_sum);
	end if;
	return new;
	end;
	$$;


ALTER FUNCTION public.contract_sponsor_player_c() OWNER TO postgres;

--
-- Name: contract_sponsor_player_d(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.contract_sponsor_player_d() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda,name) values('admin',42,'contract_sponsor_player',old.player_id,'delete',now(),old.name);
	insert into tmp_contract_sponsor_player(id,name,player_id,contract_sum) 
	values(old.player_id,old.name,old.player_id,old.contract_sum);
	end if;
	return null;
	end;
	$$;


ALTER FUNCTION public.contract_sponsor_player_d() OWNER TO postgres;

--
-- Name: contract_sponsor_player_u(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.contract_sponsor_player_u() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda,name) values('admin',42,'contract_sponsor_player' ,old.player_id,'update',now(),new.name);
	insert into tmp_contract_sponsor_player(id,name,player_id,contract_sum) 
	values(old.player_id,old.name,old.player_id,old.contract_sum);
	end if;
	return new;
	end;
	$$;


ALTER FUNCTION public.contract_sponsor_player_u() OWNER TO postgres;

--
-- Name: contract_sponsor_team_c(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.contract_sponsor_team_c() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda,name) values('admin',42,'contract_sponsor_team',new.team_id,'insert',now(),new.name);
	insert into tmp_contract_sponsor_team(id,name,team_id,contract_sum) 
	values(new.team_id,new.name,new.team_id,new.contract_sum);
	end if;
	return new;
	end;
	$$;


ALTER FUNCTION public.contract_sponsor_team_c() OWNER TO postgres;

--
-- Name: contract_sponsor_team_d(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.contract_sponsor_team_d() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda,name) values('admin',42,'contract_sponsor_team',old.team_id,'delete',now(),old.name);
	insert into tmp_contract_sponsor_team(id,name,team_id,contract_sum) 
	values(old.team_id,old.name,old.team_id,old.contract_sum);
	end if;
	return null;
	end;
	$$;


ALTER FUNCTION public.contract_sponsor_team_d() OWNER TO postgres;

--
-- Name: contract_sponsor_team_u(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.contract_sponsor_team_u() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda,name) values('admin',42,'contract_sponsor_team',old.team_id,'update',now(),new.name);
	insert into tmp_contract_sponsor_team(id,name,team_id,contract_sum) 
	values(old.team_id,old.name,old.team_id,old.contract_sum);
	end if;
	return new;
	end;
	$$;


ALTER FUNCTION public.contract_sponsor_team_u() OWNER TO postgres;

--
-- Name: insertcoach(bigint, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertcoach(_id bigint, _name character varying, _speciality character varying)
    LANGUAGE sql
    AS $$
INSERT INTO coach
			(name ,team_id ,speciality )
			VALUES
			(_Name,_id,_speciality )

$$;


ALTER PROCEDURE public.insertcoach(_id bigint, _name character varying, _speciality character varying) OWNER TO postgres;

--
-- Name: insertmanager(bigint, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertmanager(_id bigint, _name character varying)
    LANGUAGE sql
    AS $$
 INSERT INTO manager (name,team_id) VALUES (_Name,_id)
 $$;


ALTER PROCEDURE public.insertmanager(_id bigint, _name character varying) OWNER TO postgres;

--
-- Name: manager_c(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.manager_c() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'manager',new.ID,'insert',now());
	insert into tmp_manager(id,name,team_id) 
	values(new.id,new.name,new.team_id);
	end if;
	return new;
	end;
	$$;


ALTER FUNCTION public.manager_c() OWNER TO postgres;

--
-- Name: manager_d(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.manager_d() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'manager',old.ID,'delete',now());
	insert into tmp_manager(id,name,team_id) 
	values(old.id,old.name,old.team_id);
	end if;
	return null;
	end;
	$$;


ALTER FUNCTION public.manager_d() OWNER TO postgres;

--
-- Name: manager_u(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.manager_u() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'manager',new.ID,'update',now());
	insert into tmp_manager(id,name,team_id) 
	values(old.id,old.name,old.team_id);
	end if;
	return new;
	end;
	$$;


ALTER FUNCTION public.manager_u() OWNER TO postgres;

--
-- Name: managerinsert(bigint, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.managerinsert(_id bigint, _name character varying)
    LANGUAGE sql
    AS $$
INSERT INTO manager
			(name ,team_id  )
			VALUES
			(_Name,_id )

$$;


ALTER PROCEDURE public.managerinsert(_id bigint, _name character varying) OWNER TO postgres;

--
-- Name: player_c(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.player_c() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
if ((select Bol from kld where Polzovatel='admin')=true) THEN
insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'Player',new.ID,'insert',now());
insert into tmp_player(id,team_id,name,player_position,age,nationality,height,weight) 
values(new.id,new.team_id,new.name,new.player_position,new.age,new.nationality,new.height,new.weight);
end if;
return new;
end;
$$;


ALTER FUNCTION public.player_c() OWNER TO postgres;

--
-- Name: player_d(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.player_d() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
if ((select Bol from kld where Polzovatel='admin')=true) THEN
insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'Player',old.ID,'delete',now());
insert into tmp_player(id,team_id,name,player_position,age,nationality,height,weight) 
values(old.id,old.team_id,old.name,old.player_position,old.age,old.nationality,old.height,old.weight);
end if;
return null;
end;
$$;


ALTER FUNCTION public.player_d() OWNER TO postgres;

--
-- Name: player_fk_d(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.player_fk_d() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	delete from player_stats where player_id=old.id;
	delete from contract_sponsor_player where player_id=old.id;
	return old;
	end;
	$$;


ALTER FUNCTION public.player_fk_d() OWNER TO postgres;

--
-- Name: player_stats_c(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.player_stats_c() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
if ((select Bol from kld where Polzovatel='admin')=true) THEN
insert into story_help (kto,kto_id,gde,gde_id,chto,cogda,addID) values('admin',42,'Player_stats',new.player_id,'insert',now(),new.progress_id);
insert into tmp_player_stats(player_id,value,progress_id) 
values(new.player_id,new.value,new.progress_id);
end if;
return new;
end;
$$;


ALTER FUNCTION public.player_stats_c() OWNER TO postgres;

--
-- Name: player_stats_d(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.player_stats_d() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
if ((select Bol from kld where Polzovatel='admin')=true) THEN
insert into story_help (kto,kto_id,gde,gde_id,chto,cogda,addID) values('admin',42,'Player_stats',old.player_id,'delete',now(),old.progress_id);
insert into tmp_player_stats(player_id,value,progress_id) 
values(old.player_id,old.value,old.progress_id);
end if;
return null;
end;
$$;


ALTER FUNCTION public.player_stats_d() OWNER TO postgres;

--
-- Name: player_stats_u(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.player_stats_u() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda,addID,addID2) values('admin',42,'Player_stats',new.player_id,'update',now(),new.progress_id,old.player_id);
	insert into tmp_player_stats(player_id,value,progress_id) 
	values(old.player_id,old.value,old.progress_id);
	end if;
	return new;
	end;
	$$;


ALTER FUNCTION public.player_stats_u() OWNER TO postgres;

--
-- Name: player_u(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.player_u() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'Player',new.ID,'update',now());
	insert into tmp_player(id,team_id,name,player_position,age,nationality,height,weight) 
	values(old.id,old.team_id,old.name,old.player_position,old.age,old.nationality,old.height,old.weight);
	end if;
	return new;
	end;
	$$;


ALTER FUNCTION public.player_u() OWNER TO postgres;

--
-- Name: playerinsert(bigint, integer, character varying, character varying, character varying, integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.playerinsert(_id bigint, _age integer, _nationality character varying, _playerposition character varying, _height character varying, _weight integer, _name character varying)
    LANGUAGE sql
    AS $$
INSERT INTO player
			(name,age,nationality ,team_id,player_position , weight,height)
			VALUES
			(_Name,_age,_nationality,_id,_playerposition,_weight,_height )
$$;


ALTER PROCEDURE public.playerinsert(_id bigint, _age integer, _nationality character varying, _playerposition character varying, _height character varying, _weight integer, _name character varying) OWNER TO postgres;

--
-- Name: playerinsert(bigint, integer, character varying, character varying, character varying, integer, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.playerinsert(_id bigint, _age integer, _nationality character varying, _playerposition character varying, _height character varying, _weight integer, _name character varying, _contractsum integer)
    LANGUAGE sql
    AS $$
INSERT INTO player
			(name,age,nationality ,team_id,player_position , weight,height)
			VALUES
			(_Name,_age,_nationality,_id,_playerposition,_weight,_height )

$$;


ALTER PROCEDURE public.playerinsert(_id bigint, _age integer, _nationality character varying, _playerposition character varying, _height character varying, _weight integer, _name character varying, _contractsum integer) OWNER TO postgres;

--
-- Name: playerstatsinsert(bigint, character varying, bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.playerstatsinsert(_player_id bigint, _value character varying, _progressid bigint)
    LANGUAGE sql
    AS $$
INSERT INTO player_stats
			(player_id,value,progress_id)
			VALUES
			(_player_id,_value,_progressid )
$$;


ALTER PROCEDURE public.playerstatsinsert(_player_id bigint, _value character varying, _progressid bigint) OWNER TO postgres;

--
-- Name: playerstatsupdate(bigint, character varying, bigint, bigint, bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.playerstatsupdate(_player_id bigint, _value character varying, _progressid bigint, _old_playr_id bigint, _old_progress_id bigint)
    LANGUAGE sql
    AS $$
Update player_stats set
	player_id=_player_id,
	value=_value,
	progress_id=_progressid
	where (player_id=_old_playr_id and progress_id=_old_progress_id);
$$;


ALTER PROCEDURE public.playerstatsupdate(_player_id bigint, _value character varying, _progressid bigint, _old_playr_id bigint, _old_progress_id bigint) OWNER TO postgres;

--
-- Name: playerupdate(bigint, integer, character varying, character varying, character varying, integer, character varying, bigint); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.playerupdate(_id bigint, _age integer, _nationality character varying, _playerposition character varying, _height character varying, _weight integer, _name character varying, _team_id bigint)
    LANGUAGE sql
    AS $$
UPDATE player set
	name=_Name,age=_age,nationality=_nationality,
	player_position=_playerposition,height=_height,
	weight=_weight,team_id=_team_id
	where id=_id;
$$;


ALTER PROCEDURE public.playerupdate(_id bigint, _age integer, _nationality character varying, _playerposition character varying, _height character varying, _weight integer, _name character varying, _team_id bigint) OWNER TO postgres;

--
-- Name: progress_c(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.progress_c() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
if ((select Bol from kld where Polzovatel='admin')=true) THEN
insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'progress',new.ID,'insert',now());
insert into tmp_progress(id,name,unit) 
values(new.id,new.name,new.unit);
end if;
return new;
end;
$$;


ALTER FUNCTION public.progress_c() OWNER TO postgres;

--
-- Name: progress_d(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.progress_d() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
if ((select Bol from kld where Polzovatel='admin')=true) THEN
insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'progress',old.ID,'delete',now());
insert into tmp_progress(id,name,unit) 
values(old.id,old.name,old.unit);
end if;
return null;
end;
$$;


ALTER FUNCTION public.progress_d() OWNER TO postgres;

--
-- Name: progress_u(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.progress_u() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
if ((select Bol from kld where Polzovatel='admin')=true) THEN
insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'progress',new.ID,'update',now());
insert into tmp_progress(id,name,unit) 
values(old.id,old.name,old.unit);
end if;
return new;
end;
$$;


ALTER FUNCTION public.progress_u() OWNER TO postgres;

--
-- Name: progressinsert(character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.progressinsert(_name character varying, _unit character varying)
    LANGUAGE sql
    AS $$
INSERT INTO progress
			(name,unit)
			VALUES
			(_name,_unit )
$$;


ALTER PROCEDURE public.progressinsert(_name character varying, _unit character varying) OWNER TO postgres;

--
-- Name: sponsorplayerinsert(bigint, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sponsorplayerinsert(_id bigint, _name character varying, _contractsum integer)
    LANGUAGE sql
    AS $$
INSERT INTO contract_sponsor_player
			(name ,player_id , contract_sum)
			VALUES
			(_Name,_id,_contractsum )

$$;


ALTER PROCEDURE public.sponsorplayerinsert(_id bigint, _name character varying, _contractsum integer) OWNER TO postgres;

--
-- Name: sponsorteaminsert(bigint, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sponsorteaminsert(_id bigint, _name character varying, _contractsum integer)
    LANGUAGE sql
    AS $$
INSERT INTO contract_sponsor_team
			(name ,team_id , contract_sum)
			VALUES
			(_Name,_id,_contractsum )

$$;


ALTER PROCEDURE public.sponsorteaminsert(_id bigint, _name character varying, _contractsum integer) OWNER TO postgres;

--
-- Name: team_c(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.team_c() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'Team',new.ID,'insert',now());
	insert into tmp_team(id,name,city,CountOfChampions,season_place,play_off_place) 
	values(new.id,new.name,new.city,new.CountOfChampions,new.season_place,new.play_off_place) ; 
	end if;
	return new;
	end;
	$$;


ALTER FUNCTION public.team_c() OWNER TO postgres;

--
-- Name: team_d(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.team_d() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	delete from coach where team_id=old.id;
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'Team',old.ID,'delete',now());
	insert into tmp_team(id,name,city,CountOfChampions,season_place,play_off_place) 
	values(old.id,old.name,old.city,old.CountOfChampions,old.season_place,old.play_off_place);
	end if;
	return null;
	end;
	$$;


ALTER FUNCTION public.team_d() OWNER TO postgres;

--
-- Name: team_fk_d(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.team_fk_d() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	delete from coach where team_id=old.id;
	delete from player where team_id=old.id;
	delete from manager where team_id=old.id;
	delete from contract_sponsor_team where team_id=old.id;
	return old;
	end;
	$$;


ALTER FUNCTION public.team_fk_d() OWNER TO postgres;

--
-- Name: team_u(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.team_u() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	begin
	if ((select Bol from kld where Polzovatel='admin')=true) THEN
	insert into story_help (kto,kto_id,gde,gde_id,chto,cogda) values('admin',42,'Team',new.ID,'update',now());
	insert into tmp_team(id,name,city,CountOfChampions,season_place,play_off_place) 
	values(old.id,old.name,old.city,old.CountOfChampions,old.season_place,old.play_off_place);
	end if;
	return new;
	end;
	$$;


ALTER FUNCTION public.team_u() OWNER TO postgres;

--
-- Name: teaminsert(bigint, character varying, character varying, integer, integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.teaminsert(_id bigint, _name character varying, _city character varying, _countofchampions integer, _season_place integer, _play_off_place integer)
    LANGUAGE sql
    AS $$
INSERT INTO team
			(name ,city ,CountOfChampions ,season_place ,play_off_place )
			VALUES
			(_Name,_city,_CountOfChampions,_season_place,_play_off_place )

$$;


ALTER PROCEDURE public.teaminsert(_id bigint, _name character varying, _city character varying, _countofchampions integer, _season_place integer, _play_off_place integer) OWNER TO postgres;

--
-- Name: teaminstertupdatev(bigint, character varying, character varying, integer, integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.teaminstertupdatev(_id bigint, _name character varying, _city character varying, _countofchampions integer, _season_place integer, _play_off_place integer)
    LANGUAGE sql
    AS $$
INSERT INTO team
			(name ,city ,CountOfCmampions ,season_place ,play_off_place )
			VALUES
			(_Name,_city,_CountOfChampions,_season_place,_play_off_place )

$$;


ALTER PROCEDURE public.teaminstertupdatev(_id bigint, _name character varying, _city character varying, _countofchampions integer, _season_place integer, _play_off_place integer) OWNER TO postgres;

--
-- Name: teamupdate(bigint, character varying, character varying, integer, integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.teamupdate(_id bigint, _name character varying, _city character varying, _countofchampions integer, _season_place integer, _play_off_place integer)
    LANGUAGE sql
    AS $$
UPDATE team set 
name=_Name, city=_city, countofchampions=_CountOfChampions, season_place=_season_place,play_off_place=_play_off_place
where id=_id;
$$;


ALTER PROCEDURE public.teamupdate(_id bigint, _name character varying, _city character varying, _countofchampions integer, _season_place integer, _play_off_place integer) OWNER TO postgres;

--
-- Name: undo(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.undo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
		DECLARE
			ii varchar;
			iii integer;
			w integer;
			ww integer;	
			h integer;
			hh integer;
			add integer;
			add2 integer;
		begin
		update kld set Bol=false where Polzovatel='admin';
		ii = old.gde;
		iii = old.gde_id;
		add=old.addID;
		add2=old.addID2;
		if(ii='Team') then
		w=(select max(n) from tmp_team where id=iii);
		ww=(select id from story_help ORDER BY cogda LIMIT 1);
		if(old.chto='insert') then
		delete from tmp_team where n=w;
		delete from team where id=old.gde_id;
		end if;
		if(old.chto='update') then
		update team set
		name=(select Name from tmp_team where tmp_team.n=w),
		city=(select city from tmp_team where tmp_team.n=w),
		countofchampions=(select countofchampions from tmp_team where tmp_team.n=w),
		season_place=(select season_place from tmp_team where tmp_team.n=w),	
		play_off_place=(select play_off_place from tmp_team where tmp_team.n=w)
		where team.id=old.gde_id;
		delete from tmp_team where n=w;			
		end if;
		if(old.chto='delete') then
		h=(select ID from tmp_team where tmp_team.n=w);
		INSERT INTO team
		(id,name ,city ,CountOfChampions ,season_place ,play_off_place ) VALUES 
		((select id from tmp_team where tmp_team.n=w),(select name from tmp_team where tmp_team.n=w),(select city from tmp_team where tmp_team.n=w),
		(select countofchampions from tmp_team where tmp_team.n=w),
		(select season_place from tmp_team where tmp_team.n=w),(select play_off_place from tmp_team where tmp_team.n=w));
		delete from tmp_team where n=w;
		end if;
		delete from tmp_team where tmp_team.n=w;
		end if;




		if(ii='Player') then
		w = (select max(n) from tmp_player where ID=iii);
		ww=(select id from story_help
		ORDER BY cogda DESC
		LIMIT 1);
		if(old.chto='insert') then
		delete from tmp_player where n=w;
		delete from player where ID=old.gde_id;
		end if;
		if(old.chto='update') then
		update Player set 
		name=(select name from tmp_player where tmp_player.n=w),	
		team_id=(select team_id from tmp_player where tmp_player.n=w),
		player_position=(select player_position from tmp_player where tmp_player.n=w),
		age=(select age from tmp_player where tmp_player.n=w),
		nationality=(select nationality from tmp_player where tmp_player.n=w),
		height=(select height from tmp_player where tmp_player.n=w),
		weight=(select weight from tmp_player where tmp_player.n=w)
		where player.id=old.gde_id;
		delete from tmp_player where n=w;
		end if;
		if(old.chto='delete') then
		h=(select ID from tmp_player where tmp_player.n=w);
		insert into Player (ID, name,team_id,player_position,age,nationality,height,weight) values ((select ID from tmp_player where tmp_player.n=w),
		(select name from tmp_player where tmp_player.n=w),	
		(select team_id from tmp_player where tmp_player.n=w),
		(select player_position from tmp_player where tmp_player.n=w),
		(select age from tmp_player where tmp_player.n=w),
		(select nationality from tmp_player where tmp_player.n=w),
		(select height from tmp_player where tmp_player.n=w),
		(select weight from tmp_player where tmp_player.n=w));
		delete from tmp_player where n=w;
		end if;
		delete from tmp_player where tmp_player.n=w;
		end if;

		if(ii='Player_stats') then
		w = (select max(n) from tmp_player_stats where player_id=add2);
		ww=(select id from story_help
		ORDER BY cogda DESC
		  LIMIT 1);

		if(old.chto='insert') then
		delete from tmp_player_stats where n=w;
		delete from player_stats where (player_id=old.gde_id and progress_id=old.addID);
		end if;
		if(old.chto='update') then
		update player_stats set player_id=(select player_id from tmp_player_stats where tmp_player_stats.n=w),
		value=(select value from tmp_player_stats where tmp_player_stats.n=w),
		progress_id=(select progress_id from tmp_player_stats where tmp_player_stats.n=w)
		where (player_stats.player_id=old.gde_id and player_stats.progress_id=old.addID);
		delete from tmp_player_stats where n=w;
		end if;
		if(old.chto='delete') then
		h=(select player_id from tmp_player_stats where tmp_player_stats.n=w);
		insert into player_stats (player_id,value,progress_id) values ((select player_id from tmp_player_stats where tmp_player_stats.n=w),
		(select value from tmp_player_stats where tmp_player_stats.n=w),
		(select progress_id from tmp_player_stats where tmp_player_stats.n=w));
		delete from tmp_player_stats where n=w;
		end if;
		delete from tmp_player_stats where tmp_player_stats.n=w;
		end if;

		if(ii='progress') then
		w = (select max(n) from tmp_progress where ID=iii);
		ww=(select id from story_help
		ORDER BY cogda DESC
		  LIMIT 1);
		if(old.chto='insert') then
		delete from tmp_progress where n=w;
		delete from progress where ID=old.gde_id;
		end if;
		if(old.chto='update') then
		update progress set id=(select id from tmp_progress where tmp_progress.n=w),
		name=(select name from tmp_progress where tmp_progress.n=w),
		unit=(select unit from tmp_progress where tmp_progress.n=w)
		where progress.id=old.gde_id;
		delete from tmp_progress where n=w;
		end if;
		if(old.chto='delete') then
		h=(select ID from tmp_progress where tmp_progress.n=w);
		insert into progress (id,name,unit) values ((select id from tmp_progress where tmp_progress.n=w),
		(select name from tmp_progress where tmp_progress.n=w),
		(select unit from tmp_progress where tmp_progress.n=w));
		delete from tmp_progress where n=w;
		end if;
		delete from tmp_progress where tmp_progress.n=w;
		end if;
								


		if(ii='contract_sponsor_player') then
		w = (select max(n) from tmp_contract_sponsor_player where player_id=iii);
		ww=(select id from story_help
		ORDER BY cogda DESC
		  LIMIT 1);
		if(old.chto='insert') then
		delete from tmp_contract_sponsor_player where n=w;	
		delete from contract_sponsor_player where Name=old.name;
		end if;
		if(old.chto='update') then
		update contract_sponsor_player set player_id=(select player_id from tmp_contract_sponsor_player where tmp_contract_sponsor_player.n=w),
		name=(select name from tmp_contract_sponsor_player where tmp_contract_sponsor_player.n=w),
		contract_sum=(select contract_sum from tmp_contract_sponsor_player where tmp_contract_sponsor_player.n=w)
		where contract_sponsor_player.Name=old.name;
		delete from tmp_contract_sponsor_player where n=w;
		end if;
		if(old.chto='delete') then
		h=(select ID from tmp_contract_sponsor_player where tmp_contract_sponsor_player.n=w);
		insert into contract_sponsor_player (player_id,name,contract_sum) values ((select player_id from tmp_contract_sponsor_player where tmp_contract_sponsor_player.n=w),
		(select name from tmp_contract_sponsor_player where tmp_contract_sponsor_player.n=w),
		(select contract_sum from tmp_contract_sponsor_player where tmp_contract_sponsor_player.n=w))
		;
		delete from tmp_contract_sponsor_player where n=w;
		end if;
		delete from tmp_contract_sponsor_player where tmp_contract_sponsor_player.n=w;
		end if;

		if(ii='contract_sponsor_team') then
		w = (select max(n) from tmp_contract_sponsor_team where team_id=iii);
		ww=(select id from story_help
		ORDER BY cogda DESC
		  LIMIT 1);
		if(old.chto='insert') then
		delete from tmp_contract_sponsor_team where n=w;
		delete from contract_sponsor_team where name=old.Name;
		end if;
		if(old.chto='update') then
		update contract_sponsor_team set team_id=(select team_id from tmp_contract_sponsor_team where tmp_contract_sponsor_team.n=w),
		name=(select name from tmp_contract_sponsor_team where tmp_contract_sponsor_team.n=w),
		contract_sum=(select contract_sum from tmp_contract_sponsor_team where tmp_contract_sponsor_team.n=w)
		where (contract_sponsor_team.name=old.name);
		delete from tmp_contract_sponsor_team where n=w;
		end if;
		if(old.chto='delete') then
		h=(select ID from tmp_contract_sponsor_team where tmp_contract_sponsor_team.n=w);
		insert into contract_sponsor_team (team_id,name,contract_sum) values ((select team_id from tmp_contract_sponsor_team where tmp_contract_sponsor_team.n=w),
		(select name from tmp_contract_sponsor_team where tmp_contract_sponsor_team.n=w),
		(select contract_sum from tmp_contract_sponsor_team where tmp_contract_sponsor_team.n=w))
		;
		delete from tmp_contract_sponsor_team where n=w;
		end if;
		delete from tmp_contract_sponsor_team where tmp_contract_sponsor_team.n=w;
		end if;
		 
		 if(ii='coach') then
		w = (select max(n) from tmp_coach where ID=iii);
		ww=(select id from story_help
		ORDER BY cogda DESC
		  LIMIT 1);
		if(old.chto='insert') then
		delete from tmp_coach where n=w;
		delete from coach where ID=old.gde_id;
		end if;
		if(old.chto='update') then
		update coach set id=(select id from tmp_coach where tmp_coach.n=w),
		name=(select name from tmp_coach where tmp_coach.n=w),
		speciality=(select speciality from tmp_coach where tmp_coach.n=w),
		team_id=(select  team_id from tmp_coach where tmp_coach.n=w)
		where coach.id=old.gde_id;
		delete from tmp_coach where n=w;
		end if;
		if(old.chto='delete') then
		h=(select ID from tmp_coach where tmp_coach.n=w);
		insert into coach (id,name,speciality,team_id) values ((select id from tmp_coach where tmp_coach.n=w),
		(select name from tmp_coach where tmp_coach.n=w),
		(select speciality from tmp_coach where tmp_coach.n=w),
		(select team_id from tmp_coach where tmp_coach.n=w));
		delete from tmp_coach where n=w;
		end if;
		delete from tmp_coach where tmp_coach.n=w;
		end if;

		 if(ii='manager') then
		w = (select max(n) from tmp_manager where ID=iii);
		ww=(select id from story_help
		ORDER BY cogda DESC
		  LIMIT 1);
		if(old.chto='insert') then	
		delete from tmp_manager where n=w;
		delete from manager where ID=old.gde_id;
		end if;
		if(old.chto='update') then
		update manager set id=(select id from tmp_manager where tmp_manager.n=w),
		name=(select name from tmp_manager where tmp_manager.n=w),
		team_id=(select team_id from tmp_manager where tmp_manager.n=w)
		where manager.id=old.gde_id;
		delete from tmp_manager where n=w;
		end if;
		if(old.chto='delete') then
		h=(select ID from tmp_manager where tmp_manager.n=w);
		insert into manager (id,name,team_id) values ((select id from tmp_manager where tmp_manager.n=w),
		(select name from tmp_manager where tmp_manager.n=w),
		(select team_id from tmp_manager where tmp_manager.n=w));
		delete from tmp_manager where n=w;
		end if;
		delete from tmp_manager where tmp_manager.n=w;
		end if;
		update kld set Bol=true where Polzovatel='admin';
		RETURN NULL;
		end;
		$$;


ALTER FUNCTION public.undo() OWNER TO postgres;

--
-- Name: updatemanger(bigint, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.updatemanger(_id bigint, _name character varying, _team_id integer)
    LANGUAGE sql
    AS $$
 	UPDATE manager set
 		name=_Name,
 		team_id=_team_id
 		where id=_id;
 	$$;


ALTER PROCEDURE public.updatemanger(_id bigint, _name character varying, _team_id integer) OWNER TO postgres;

--
-- Name: updateprogress(bigint, character varying, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.updateprogress(_id bigint, _name character varying, _unit character varying)
    LANGUAGE sql
    AS $$
UPDATE progress set
		name=_Name,
		unit=_Unit
		where id=_id;
$$;


ALTER PROCEDURE public.updateprogress(_id bigint, _name character varying, _unit character varying) OWNER TO postgres;

--
-- Name: updatesponsorplayer(bigint, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.updatesponsorplayer(_id bigint, _name character varying, _contractsum integer)
    LANGUAGE sql
    AS $$
UPDATE contract_sponsor_player set
		name=_Name,
		contract_sum=_contractsum,
		player_id=_id
		where name=_Name;
$$;


ALTER PROCEDURE public.updatesponsorplayer(_id bigint, _name character varying, _contractsum integer) OWNER TO postgres;

--
-- Name: updatesponsorplayer(bigint, character varying, integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.updatesponsorplayer(_id bigint, _name character varying, _contractsum integer, oldname character varying)
    LANGUAGE sql
    AS $$
UPDATE contract_sponsor_player set
		name=_Name,
		contract_sum=_contractsum,
		player_id=_id
		where name=oldName;
$$;


ALTER PROCEDURE public.updatesponsorplayer(_id bigint, _name character varying, _contractsum integer, oldname character varying) OWNER TO postgres;

--
-- Name: updatesponsorteam(bigint, character varying, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.updatesponsorteam(_id bigint, _name character varying, _contractsum integer)
    LANGUAGE sql
    AS $$
UPDATE contract_sponsor_team set 
		name=_Name,
		contract_sum=_contractsum,
		team_id=_id
		where name=_Name;
$$;


ALTER PROCEDURE public.updatesponsorteam(_id bigint, _name character varying, _contractsum integer) OWNER TO postgres;

--
-- Name: updatesponsorteam(bigint, character varying, integer, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.updatesponsorteam(_id bigint, _name character varying, _contractsum integer, oldname character varying)
    LANGUAGE sql
    AS $$
UPDATE contract_sponsor_team set 
		name=_Name,
		contract_sum=_contractsum,
		team_id=_id
		where name=oldName;
$$;


ALTER PROCEDURE public.updatesponsorteam(_id bigint, _name character varying, _contractsum integer, oldname character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: coach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.coach (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    team_id bigint,
    speciality character varying(100) NOT NULL
);


ALTER TABLE public.coach OWNER TO postgres;

--
-- Name: coach_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.coach_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.coach_id_seq OWNER TO postgres;

--
-- Name: coach_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.coach_id_seq OWNED BY public.coach.id;


--
-- Name: contract_sponsor_player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contract_sponsor_player (
    contract_sum integer,
    name character varying(100) NOT NULL,
    player_id bigint
);


ALTER TABLE public.contract_sponsor_player OWNER TO postgres;

--
-- Name: contract_sponsor_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contract_sponsor_team (
    contract_sum integer,
    name character varying(100) NOT NULL,
    team_id bigint
);


ALTER TABLE public.contract_sponsor_team OWNER TO postgres;

--
-- Name: kld; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kld (
    bol boolean,
    polzovatel character varying NOT NULL
);


ALTER TABLE public.kld OWNER TO postgres;

--
-- Name: manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manager (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    team_id bigint
);


ALTER TABLE public.manager OWNER TO postgres;

--
-- Name: manager_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.manager_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.manager_id_seq OWNER TO postgres;

--
-- Name: manager_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.manager_id_seq OWNED BY public.manager.id;


--
-- Name: player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player (
    id bigint NOT NULL,
    team_id bigint,
    player_position character varying(100) NOT NULL,
    name character varying(50) NOT NULL,
    age integer NOT NULL,
    nationality character varying(20) NOT NULL,
    height character varying(10) NOT NULL,
    weight integer NOT NULL,
    CONSTRAINT player_age_check CHECK (((age > 15) AND (age <= 38))),
    CONSTRAINT player_player_position_check CHECK (((player_position)::text = ANY (ARRAY[('PF'::character varying)::text, ('PG'::character varying)::text, ('SF'::character varying)::text, ('C'::character varying)::text, ('SG'::character varying)::text])))
);


ALTER TABLE public.player OWNER TO postgres;

--
-- Name: player_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.player_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.player_id_seq OWNER TO postgres;

--
-- Name: player_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.player_id_seq OWNED BY public.player.id;


--
-- Name: player_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.player_stats (
    player_id bigint NOT NULL,
    value character varying(20),
    progress_id bigint NOT NULL
);


ALTER TABLE public.player_stats OWNER TO postgres;

--
-- Name: progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.progress (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    unit character varying(50)
);


ALTER TABLE public.progress OWNER TO postgres;

--
-- Name: progress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.progress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.progress_id_seq OWNER TO postgres;

--
-- Name: progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.progress_id_seq OWNED BY public.progress.id;


--
-- Name: story_help; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.story_help (
    id integer NOT NULL,
    kto character varying,
    kto_id integer,
    gde character varying,
    gde_id integer,
    chto character varying,
    cogda timestamp with time zone,
    addid integer,
    name character varying,
    addid2 integer
);


ALTER TABLE public.story_help OWNER TO postgres;

--
-- Name: story_help_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.story_help_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.story_help_id_seq OWNER TO postgres;

--
-- Name: story_help_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.story_help_id_seq OWNED BY public.story_help.id;


--
-- Name: team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team (
    id bigint NOT NULL,
    name character varying(100) NOT NULL,
    city character varying(100) NOT NULL,
    countofchampions integer,
    season_place integer,
    play_off_place integer
);


ALTER TABLE public.team OWNER TO postgres;

--
-- Name: team_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_id_seq OWNER TO postgres;

--
-- Name: team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_id_seq OWNED BY public.team.id;


--
-- Name: tmp_coach; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_coach (
    n integer NOT NULL,
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    team_id bigint,
    speciality character varying(100) NOT NULL
);


ALTER TABLE public.tmp_coach OWNER TO postgres;

--
-- Name: tmp_coach_n_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_coach_n_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_coach_n_seq OWNER TO postgres;

--
-- Name: tmp_coach_n_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_coach_n_seq OWNED BY public.tmp_coach.n;


--
-- Name: tmp_contract_sponsor_player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_contract_sponsor_player (
    n integer NOT NULL,
    id integer NOT NULL,
    contract_sum integer,
    name character varying(100) NOT NULL,
    player_id bigint
);


ALTER TABLE public.tmp_contract_sponsor_player OWNER TO postgres;

--
-- Name: tmp_contract_sponsor_player_n_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_contract_sponsor_player_n_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_contract_sponsor_player_n_seq OWNER TO postgres;

--
-- Name: tmp_contract_sponsor_player_n_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_contract_sponsor_player_n_seq OWNED BY public.tmp_contract_sponsor_player.n;


--
-- Name: tmp_contract_sponsor_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_contract_sponsor_team (
    n integer NOT NULL,
    contract_sum integer,
    name character varying(100) NOT NULL,
    id integer NOT NULL,
    team_id bigint
);


ALTER TABLE public.tmp_contract_sponsor_team OWNER TO postgres;

--
-- Name: tmp_contract_sponsor_team_n_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_contract_sponsor_team_n_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_contract_sponsor_team_n_seq OWNER TO postgres;

--
-- Name: tmp_contract_sponsor_team_n_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_contract_sponsor_team_n_seq OWNED BY public.tmp_contract_sponsor_team.n;


--
-- Name: tmp_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_manager (
    n integer NOT NULL,
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    team_id bigint
);


ALTER TABLE public.tmp_manager OWNER TO postgres;

--
-- Name: tmp_manager_n_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_manager_n_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_manager_n_seq OWNER TO postgres;

--
-- Name: tmp_manager_n_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_manager_n_seq OWNED BY public.tmp_manager.n;


--
-- Name: tmp_player; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_player (
    n integer NOT NULL,
    id integer,
    team_id bigint,
    player_position character varying(100) NOT NULL,
    name character varying(50) NOT NULL,
    age integer NOT NULL,
    nationality character varying(20) NOT NULL,
    height character varying(10) NOT NULL,
    weight integer NOT NULL,
    CONSTRAINT tmp_player_age_check CHECK (((age > 15) AND (age <= 38))),
    CONSTRAINT tmp_player_player_position_check CHECK (((player_position)::text = ANY (ARRAY[('PF'::character varying)::text, ('PG'::character varying)::text, ('SF'::character varying)::text, ('C'::character varying)::text, ('SG'::character varying)::text])))
);


ALTER TABLE public.tmp_player OWNER TO postgres;

--
-- Name: tmp_player_n_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_player_n_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_player_n_seq OWNER TO postgres;

--
-- Name: tmp_player_n_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_player_n_seq OWNED BY public.tmp_player.n;


--
-- Name: tmp_player_stats; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_player_stats (
    n integer NOT NULL,
    player_id bigint,
    value character varying(20),
    progress_id bigint
);


ALTER TABLE public.tmp_player_stats OWNER TO postgres;

--
-- Name: tmp_player_stats_n_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_player_stats_n_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_player_stats_n_seq OWNER TO postgres;

--
-- Name: tmp_player_stats_n_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_player_stats_n_seq OWNED BY public.tmp_player_stats.n;


--
-- Name: tmp_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_progress (
    n integer NOT NULL,
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    unit character varying(50)
);


ALTER TABLE public.tmp_progress OWNER TO postgres;

--
-- Name: tmp_progress_n_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_progress_n_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_progress_n_seq OWNER TO postgres;

--
-- Name: tmp_progress_n_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_progress_n_seq OWNED BY public.tmp_progress.n;


--
-- Name: tmp_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tmp_team (
    n integer NOT NULL,
    id integer,
    name character varying(100),
    city character varying(100),
    countofchampions integer,
    season_place integer,
    play_off_place integer
);


ALTER TABLE public.tmp_team OWNER TO postgres;

--
-- Name: tmp_team_n_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tmp_team_n_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tmp_team_n_seq OWNER TO postgres;

--
-- Name: tmp_team_n_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tmp_team_n_seq OWNED BY public.tmp_team.n;


--
-- Name: coach id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach ALTER COLUMN id SET DEFAULT nextval('public.coach_id_seq'::regclass);


--
-- Name: manager id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager ALTER COLUMN id SET DEFAULT nextval('public.manager_id_seq'::regclass);


--
-- Name: player id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player ALTER COLUMN id SET DEFAULT nextval('public.player_id_seq'::regclass);


--
-- Name: progress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.progress ALTER COLUMN id SET DEFAULT nextval('public.progress_id_seq'::regclass);


--
-- Name: story_help id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.story_help ALTER COLUMN id SET DEFAULT nextval('public.story_help_id_seq'::regclass);


--
-- Name: team id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team ALTER COLUMN id SET DEFAULT nextval('public.team_id_seq'::regclass);


--
-- Name: tmp_coach n; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_coach ALTER COLUMN n SET DEFAULT nextval('public.tmp_coach_n_seq'::regclass);


--
-- Name: tmp_contract_sponsor_player n; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_contract_sponsor_player ALTER COLUMN n SET DEFAULT nextval('public.tmp_contract_sponsor_player_n_seq'::regclass);


--
-- Name: tmp_contract_sponsor_team n; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_contract_sponsor_team ALTER COLUMN n SET DEFAULT nextval('public.tmp_contract_sponsor_team_n_seq'::regclass);


--
-- Name: tmp_manager n; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_manager ALTER COLUMN n SET DEFAULT nextval('public.tmp_manager_n_seq'::regclass);


--
-- Name: tmp_player n; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_player ALTER COLUMN n SET DEFAULT nextval('public.tmp_player_n_seq'::regclass);


--
-- Name: tmp_player_stats n; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_player_stats ALTER COLUMN n SET DEFAULT nextval('public.tmp_player_stats_n_seq'::regclass);


--
-- Name: tmp_progress n; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_progress ALTER COLUMN n SET DEFAULT nextval('public.tmp_progress_n_seq'::regclass);


--
-- Name: tmp_team n; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_team ALTER COLUMN n SET DEFAULT nextval('public.tmp_team_n_seq'::regclass);


--
-- Data for Name: coach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.coach (id, name, team_id, speciality) FROM stdin;
\.
COPY public.coach (id, name, team_id, speciality) FROM '$$PATH$$/3031.dat';

--
-- Data for Name: contract_sponsor_player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contract_sponsor_player (contract_sum, name, player_id) FROM stdin;
\.
COPY public.contract_sponsor_player (contract_sum, name, player_id) FROM '$$PATH$$/3033.dat';

--
-- Data for Name: contract_sponsor_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contract_sponsor_team (contract_sum, name, team_id) FROM stdin;
\.
COPY public.contract_sponsor_team (contract_sum, name, team_id) FROM '$$PATH$$/3034.dat';

--
-- Data for Name: kld; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kld (bol, polzovatel) FROM stdin;
\.
COPY public.kld (bol, polzovatel) FROM '$$PATH$$/3035.dat';

--
-- Data for Name: manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manager (id, name, team_id) FROM stdin;
\.
COPY public.manager (id, name, team_id) FROM '$$PATH$$/3036.dat';

--
-- Data for Name: player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player (id, team_id, player_position, name, age, nationality, height, weight) FROM stdin;
\.
COPY public.player (id, team_id, player_position, name, age, nationality, height, weight) FROM '$$PATH$$/3038.dat';

--
-- Data for Name: player_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.player_stats (player_id, value, progress_id) FROM stdin;
\.
COPY public.player_stats (player_id, value, progress_id) FROM '$$PATH$$/3040.dat';

--
-- Data for Name: progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.progress (id, name, unit) FROM stdin;
\.
COPY public.progress (id, name, unit) FROM '$$PATH$$/3041.dat';

--
-- Data for Name: story_help; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.story_help (id, kto, kto_id, gde, gde_id, chto, cogda, addid, name, addid2) FROM stdin;
\.
COPY public.story_help (id, kto, kto_id, gde, gde_id, chto, cogda, addid, name, addid2) FROM '$$PATH$$/3043.dat';

--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team (id, name, city, countofchampions, season_place, play_off_place) FROM stdin;
\.
COPY public.team (id, name, city, countofchampions, season_place, play_off_place) FROM '$$PATH$$/3045.dat';

--
-- Data for Name: tmp_coach; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_coach (n, id, name, team_id, speciality) FROM stdin;
\.
COPY public.tmp_coach (n, id, name, team_id, speciality) FROM '$$PATH$$/3047.dat';

--
-- Data for Name: tmp_contract_sponsor_player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_contract_sponsor_player (n, id, contract_sum, name, player_id) FROM stdin;
\.
COPY public.tmp_contract_sponsor_player (n, id, contract_sum, name, player_id) FROM '$$PATH$$/3049.dat';

--
-- Data for Name: tmp_contract_sponsor_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_contract_sponsor_team (n, contract_sum, name, id, team_id) FROM stdin;
\.
COPY public.tmp_contract_sponsor_team (n, contract_sum, name, id, team_id) FROM '$$PATH$$/3051.dat';

--
-- Data for Name: tmp_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_manager (n, id, name, team_id) FROM stdin;
\.
COPY public.tmp_manager (n, id, name, team_id) FROM '$$PATH$$/3053.dat';

--
-- Data for Name: tmp_player; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_player (n, id, team_id, player_position, name, age, nationality, height, weight) FROM stdin;
\.
COPY public.tmp_player (n, id, team_id, player_position, name, age, nationality, height, weight) FROM '$$PATH$$/3055.dat';

--
-- Data for Name: tmp_player_stats; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_player_stats (n, player_id, value, progress_id) FROM stdin;
\.
COPY public.tmp_player_stats (n, player_id, value, progress_id) FROM '$$PATH$$/3057.dat';

--
-- Data for Name: tmp_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_progress (n, id, name, unit) FROM stdin;
\.
COPY public.tmp_progress (n, id, name, unit) FROM '$$PATH$$/3059.dat';

--
-- Data for Name: tmp_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tmp_team (n, id, name, city, countofchampions, season_place, play_off_place) FROM stdin;
\.
COPY public.tmp_team (n, id, name, city, countofchampions, season_place, play_off_place) FROM '$$PATH$$/3061.dat';

--
-- Name: coach_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.coach_id_seq', 33, true);


--
-- Name: manager_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.manager_id_seq', 21, true);


--
-- Name: player_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.player_id_seq', 26, true);


--
-- Name: progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.progress_id_seq', 7, true);


--
-- Name: story_help_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.story_help_id_seq', 14, true);


--
-- Name: team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_id_seq', 49, true);


--
-- Name: tmp_coach_n_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_coach_n_seq', 98, true);


--
-- Name: tmp_contract_sponsor_player_n_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_contract_sponsor_player_n_seq', 49, true);


--
-- Name: tmp_contract_sponsor_team_n_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_contract_sponsor_team_n_seq', 5, true);


--
-- Name: tmp_manager_n_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_manager_n_seq', 41, true);


--
-- Name: tmp_player_n_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_player_n_seq', 22, true);


--
-- Name: tmp_player_stats_n_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_player_stats_n_seq', 72, true);


--
-- Name: tmp_progress_n_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_progress_n_seq', 4, true);


--
-- Name: tmp_team_n_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tmp_team_n_seq', 88, true);


--
-- Name: coach coach_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach
    ADD CONSTRAINT coach_pkey PRIMARY KEY (id);


--
-- Name: contract_sponsor_player contract_sponsor_player_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contract_sponsor_player
    ADD CONSTRAINT contract_sponsor_player_pkey PRIMARY KEY (name);


--
-- Name: contract_sponsor_team contract_sponsor_team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contract_sponsor_team
    ADD CONSTRAINT contract_sponsor_team_pkey PRIMARY KEY (name);


--
-- Name: kld kld_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kld
    ADD CONSTRAINT kld_pkey PRIMARY KEY (polzovatel);


--
-- Name: manager manager_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT manager_pkey PRIMARY KEY (id);


--
-- Name: player player_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT player_pkey PRIMARY KEY (id);


--
-- Name: player_stats player_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_stats
    ADD CONSTRAINT player_stats_pkey PRIMARY KEY (player_id, progress_id);


--
-- Name: progress progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.progress
    ADD CONSTRAINT progress_pkey PRIMARY KEY (id);


--
-- Name: story_help story_help_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.story_help
    ADD CONSTRAINT story_help_pk PRIMARY KEY (id);


--
-- Name: team team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_pkey PRIMARY KEY (id);


--
-- Name: tmp_progress tmp_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tmp_progress
    ADD CONSTRAINT tmp_progress_pkey PRIMARY KEY (id);


--
-- Name: coach coach_c; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER coach_c BEFORE INSERT ON public.coach FOR EACH ROW EXECUTE FUNCTION public.coach_c();


--
-- Name: coach coach_d; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER coach_d AFTER DELETE ON public.coach FOR EACH ROW EXECUTE FUNCTION public.coach_d();


--
-- Name: coach coach_u; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER coach_u BEFORE UPDATE ON public.coach FOR EACH ROW EXECUTE FUNCTION public.coach_u();


--
-- Name: contract_sponsor_player contract_sponsor_player_c; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER contract_sponsor_player_c BEFORE INSERT ON public.contract_sponsor_player FOR EACH ROW EXECUTE FUNCTION public.contract_sponsor_player_c();


--
-- Name: contract_sponsor_player contract_sponsor_player_d; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER contract_sponsor_player_d AFTER DELETE ON public.contract_sponsor_player FOR EACH ROW EXECUTE FUNCTION public.contract_sponsor_player_d();


--
-- Name: contract_sponsor_player contract_sponsor_player_u; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER contract_sponsor_player_u BEFORE UPDATE ON public.contract_sponsor_player FOR EACH ROW EXECUTE FUNCTION public.contract_sponsor_player_u();


--
-- Name: contract_sponsor_team contract_sponsor_team_c; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER contract_sponsor_team_c BEFORE INSERT ON public.contract_sponsor_team FOR EACH ROW EXECUTE FUNCTION public.contract_sponsor_team_c();


--
-- Name: contract_sponsor_team contract_sponsor_team_d; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER contract_sponsor_team_d AFTER DELETE ON public.contract_sponsor_team FOR EACH ROW EXECUTE FUNCTION public.contract_sponsor_team_d();


--
-- Name: contract_sponsor_team contract_sponsor_team_u; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER contract_sponsor_team_u BEFORE UPDATE ON public.contract_sponsor_team FOR EACH ROW EXECUTE FUNCTION public.contract_sponsor_team_u();


--
-- Name: story_help get_back; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER get_back AFTER DELETE ON public.story_help FOR EACH ROW EXECUTE FUNCTION public.undo();


--
-- Name: manager manager_c; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER manager_c BEFORE INSERT ON public.manager FOR EACH ROW EXECUTE FUNCTION public.manager_c();


--
-- Name: manager manager_d; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER manager_d AFTER DELETE ON public.manager FOR EACH ROW EXECUTE FUNCTION public.manager_d();


--
-- Name: manager manager_u; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER manager_u BEFORE UPDATE ON public.manager FOR EACH ROW EXECUTE FUNCTION public.manager_u();


--
-- Name: player player_c; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER player_c BEFORE INSERT ON public.player FOR EACH ROW EXECUTE FUNCTION public.player_c();


--
-- Name: player player_d; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER player_d AFTER DELETE ON public.player FOR EACH ROW EXECUTE FUNCTION public.player_d();


--
-- Name: player player_fk_d; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER player_fk_d BEFORE DELETE ON public.player FOR EACH ROW EXECUTE FUNCTION public.player_fk_d();


--
-- Name: player_stats player_stats_c; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER player_stats_c BEFORE INSERT ON public.player_stats FOR EACH ROW EXECUTE FUNCTION public.player_stats_c();


--
-- Name: player_stats player_stats_d; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER player_stats_d AFTER DELETE ON public.player_stats FOR EACH ROW EXECUTE FUNCTION public.player_stats_d();


--
-- Name: player_stats player_stats_u; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER player_stats_u BEFORE UPDATE ON public.player_stats FOR EACH ROW EXECUTE FUNCTION public.player_stats_u();


--
-- Name: player player_u; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER player_u BEFORE UPDATE ON public.player FOR EACH ROW EXECUTE FUNCTION public.player_u();


--
-- Name: progress progress_c; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER progress_c BEFORE INSERT ON public.progress FOR EACH ROW EXECUTE FUNCTION public.progress_c();


--
-- Name: progress progress_d; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER progress_d AFTER DELETE ON public.progress FOR EACH ROW EXECUTE FUNCTION public.progress_d();


--
-- Name: progress progress_u; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER progress_u BEFORE UPDATE ON public.progress FOR EACH ROW EXECUTE FUNCTION public.progress_u();


--
-- Name: team team_c; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER team_c BEFORE INSERT ON public.team FOR EACH ROW EXECUTE FUNCTION public.team_c();


--
-- Name: team team_d; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER team_d AFTER DELETE ON public.team FOR EACH ROW EXECUTE FUNCTION public.team_d();


--
-- Name: team team_fk_d; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER team_fk_d BEFORE DELETE ON public.team FOR EACH ROW EXECUTE FUNCTION public.team_fk_d();


--
-- Name: team team_u; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER team_u BEFORE UPDATE ON public.team FOR EACH ROW EXECUTE FUNCTION public.team_u();


--
-- Name: coach coachtoteam; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.coach
    ADD CONSTRAINT coachtoteam FOREIGN KEY (team_id) REFERENCES public.team(id);


--
-- Name: contract_sponsor_player contractsponsorplayer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contract_sponsor_player
    ADD CONSTRAINT contractsponsorplayer FOREIGN KEY (player_id) REFERENCES public.player(id);


--
-- Name: contract_sponsor_team contractsponsorteam; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contract_sponsor_team
    ADD CONSTRAINT contractsponsorteam FOREIGN KEY (team_id) REFERENCES public.team(id) ON DELETE CASCADE;


--
-- Name: manager managerstoteam; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT managerstoteam FOREIGN KEY (team_id) REFERENCES public.team(id) ON DELETE CASCADE;


--
-- Name: player_stats player_statstoprogess; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player_stats
    ADD CONSTRAINT player_statstoprogess FOREIGN KEY (progress_id) REFERENCES public.progress(id) ON DELETE CASCADE;


--
-- Name: player playerteam; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.player
    ADD CONSTRAINT playerteam FOREIGN KEY (team_id) REFERENCES public.team(id);


--
-- PostgreSQL database dump complete
--

